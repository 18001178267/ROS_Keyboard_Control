#!/usr/bin/env python

import rospy
import sys
from sensor_msgs.msg import JointState
from std_msgs.msg import Header


def talker():
    variable=1.5
    num=0.2
    a=1.57
    b=0
    c=0
    d=0
    e=0
    f=0
    g=0
    h=0
    i=0
    j=0
    k=0
    l=0
    m=0
    n=0
    o=0
    p=0
    q=0
    r=0
    s=0
    t=0
    u=0
    v=0
    w=0
    x=0
    y=0
    z=0
    aa=0
    bb=0
    cc=0
    g=g+5*num
    h=h-1*num
    i=i-1*num
    j=j-1*num
    k=k-1*num
    l=l-1*num

    m=m-1*num
    n=n-1*num
    o=o-1*num
    p=p-1*num
    q=q-1*num

    r=r+1*num
    s=s+1*num
    t=t+1*num
    u=u+1*num
    v=v+1*num

    w=w+1*num
    x=x+1*num
    y=y+1*num
    z=z+1*num
    aa=aa+1*num

    bb=bb-5*num
    cc=cc
    pub = rospy.Publisher('joint_states', JointState, queue_size=30)
    rospy.init_node('joint_state_publisher')
    rate = rospy.Rate(10) # 10hz
    hello_str = JointState()
    while not rospy.is_shutdown():
	hello_str.header.stamp = rospy.Time.now()

	sin=[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
	sin[0]=g
	sin[1]=h
	sin[2]=i
	sin[3]=j
	sin[4]=k
	sin[5]=l
	sin[6]=m
	sin[7]=n
	sin[8]=o
	sin[9]=p
	sin[10]=q
	sin[11]=r
	sin[12]=s
	sin[13]=t
	sin[14]=u
	sin[15]=v
	sin[16]=w
	sin[17]=x
	sin[18]=y
	sin[19]=z
	sin[20]=aa
              
	for i in range(100):
	  for j in range (1):
		sin.insert(0,sin.pop())
	        print(sin)
		g=sin[0]
		h=sin[1]
		i=sin[2]
		j=sin[3]
		k=sin[4]
		l=sin[5]
		m=sin[6]
		n=sin[7]
		o=sin[8]
		p=sin[9]
		q=sin[10]
		r=sin[11]
		s=sin[12]
		t=sin[13]
		u=sin[14]
		v=sin[15]
		w=sin[16]
		x=sin[17]
		y=sin[18]
		z=sin[19]
		aa=sin[20]

		hello_str.header = Header()
		hello_str.header.stamp = rospy.Time.now()
		hello_str.name = [ 'la1', 'la2', 'la-lb' ,'lb1', 'lb2', 'lb-lc' ,'lc1','lc2','lc-ld','ld1','ld2','ld-le','le1','le2','le-lf','lf1','lf2','lf-lg','lg1','lg2','lg-lh','lh1','lh2','lh-li','li1','li2','li-lj','lj1','lj2']
		hello_str.position = [ a, b, c, d, e, f, g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc]
		hello_str.velocity = []
		hello_str.effort = []
		pub.publish(hello_str)
		rate.sleep() 


	 

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
