#!/usr/bin/env python

import rospy
import sys
from sensor_msgs.msg import JointState
from std_msgs.msg import Header


def talker():
    a=1.15
    b=1.15
    c=1.15
    d=1.15
    e=1.15
    f=1.15
    g=1.15
    h=1.15
    i=1.15
    j=1.15
    k=1.15
    l=1.15
    m=1.15
    n=1.15
    o=1.15
    p=1.15
    q=1.15
    r=1.15
    s=1.15
    t=1.15
    u=1.15
    v=1.15
    w=1.15
    x=1.15
    y=1.15
    z=1.15
    aa=1.15
    bb=1.15
    cc=1.15
    pub = rospy.Publisher('joint_states', JointState, queue_size=10)
    rospy.init_node('joint_state_publisher')
    rate = rospy.Rate(2) # 10hz
    hello_str = JointState()
    while not rospy.is_shutdown():
      hello_str.header.stamp = rospy.Time.now()
      

      for i in range(45):
	      a=a+0.05
	      b=b-0.05
	      c=c+0.05
	      d=d-0.05
	      e=e+0.05
	      f=f-0.05
	      g=g+0.05
	      h=h+0.05
	      i=i-0.05
	      j=j+0.05
	      k=k-0.05
	      l=l+0.05
	      m=m-0.05
	      n=n+0.05
	      o=o+0.05
	      p=p+0.05
	      q=q-0.05
	      r=r+0.05
	      s=s-0.05
	      t=t+0.05
	      u=u-0.05
	      v=v+0.05
	      w=w+0.05
	      x=x-0.05
	      y=y+0.05
	      z=z-0.05
	      aa=aa+0.05
	      bb=bb-0.05
	      cc=cc+0.05

	      hello_str.header = Header()
	      hello_str.header.stamp = rospy.Time.now()
	      hello_str.name = [ 'la1', 'la2', 'la-lb' ,'lb1', 'lb2', 'lb-lc' ,'lc1','lc2','lc-ld','ld1','ld2','ld-le','le1','le2','le-lf','lf1','lf2','lf-lg','lg1','lg2','lg-lh','lh1','lh2','lh-li','li1','li2','li-lj','lj1','lj2']
	      hello_str.position = [ a, b, c, d, e, f, g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc]
	      hello_str.velocity = []
	      hello_str.effort = []
	      pub.publish(hello_str)
	      rate.sleep()

	 

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
