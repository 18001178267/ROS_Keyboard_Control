#!/usr/bin/env python

import rospy
import sys
from sensor_msgs.msg import JointState
from std_msgs.msg import Header


def talker():
    a=1.15
    b=1.15
    pub = rospy.Publisher('joint_states', JointState, queue_size=10)
    rospy.init_node('joint_state_publisher')
    rate = rospy.Rate(10) # 10hz
    hello_str = JointState()
    while not rospy.is_shutdown():
      hello_str.header.stamp = rospy.Time.now()
      

      for i in range(45):
	      a=a+0.05
	      b=b-0.05
	      hello_str.header = Header()
	      hello_str.header.stamp = rospy.Time.now()
	      hello_str.name = [ 'joint1', 'joint2']
	      hello_str.position = [ a, b]
	      hello_str.velocity = []
	      hello_str.effort = []
	      pub.publish(hello_str)
	      rate.sleep()

	 

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
