#!/usr/bin/env python

import rospy
import sys
from sensor_msgs.msg import JointState
from std_msgs.msg import Header
import time


def talker():
    joint=[1.57,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0] #29ge
    pub = rospy.Publisher('joint_states', JointState, queue_size=30)
    rospy.init_node('joint_state_publisher')
    rate = rospy.Rate(3) # 10hz
    hello_str = JointState()
    while not rospy.is_shutdown():
	hello_str.header.stamp = rospy.Time.now()           	

	try:
          str_1=sys.stdin.read(1)
          if (str_1) == 'w':
		for w in range(30):		
			for i in range(1,14):		
				joint[-1*i]=joint[-1*i]+0.016
			for i in range(14,29):		
				joint[-1*i]=joint[-1*i]+0.01
			rospy.sleep(0.2)
			hello_str.header = Header()
			hello_str.header.stamp = rospy.Time.now()
			hello_str.name = [ 'la1', 'la2', 'la-lb' ,'lb1', 'lb2', 'lb-lc' ,'lc1','lc2','lc-ld','ld1','ld2','ld-le','le1','le2','le-lf','lf1','lf2','lf-lg','lg1','lg2','lg-lh','lh1','lh2','lh-li','li1','li2','li-lj','lj1','lj2']
			hello_str.position = [ joint[0], joint[1], joint[2], joint[3], joint[4], joint[5], joint[6],joint[7], joint[8], joint[9], joint[10], joint[11], joint[12], joint[13],joint[14], joint[15], joint[16], joint[17], joint[18], joint[19], joint[20],joint[21], joint[22], joint[23], joint[24], joint[25], joint[26], joint[27],joint[28]]
			hello_str.velocity = []
			hello_str.effort = []
			pub.publish(hello_str)
			rate.sleep() 
          if (str_1) == 's':
		for w in range(30):
			for i in range(1,14):		
				joint[-1*i]=joint[-1*i]-0.016
			for i in range(14,29):		
				joint[-1*i]=joint[-1*i]-0.01
			rospy.sleep(0.2)
			hello_str.header = Header()
			hello_str.header.stamp = rospy.Time.now()
			hello_str.name = [ 'la1', 'la2', 'la-lb' ,'lb1', 'lb2', 'lb-lc' ,'lc1','lc2','lc-ld','ld1','ld2','ld-le','le1','le2','le-lf','lf1','lf2','lf-lg','lg1','lg2','lg-lh','lh1','lh2','lh-li','li1','li2','li-lj','lj1','lj2']
			hello_str.position = [ joint[0], joint[1], joint[2], joint[3], joint[4], joint[5], joint[6],joint[7], joint[8], joint[9], joint[10], joint[11], joint[12], joint[13],joint[14], joint[15], joint[16], joint[17], joint[18], joint[19], joint[20],joint[21], joint[22], joint[23], joint[24], joint[25], joint[26], joint[27],joint[28]]
			hello_str.velocity = []
			hello_str.effort = []
			pub.publish(hello_str)
			rate.sleep() 
        except:
          pass



	 

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
