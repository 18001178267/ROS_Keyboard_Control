#!/usr/bin/env python

import rospy
import sys
from sensor_msgs.msg import JointState
from std_msgs.msg import Header


def talker():
    joint=[1.57,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0] #29ge
    sin_value=[0.9,0.6,0.3,0,-0.3,-0.6,-0.9,-0.6,-0.3,0,0.3,0.6,0.9,0.6,0.3,0,-0.3,-0.6,-0.9,-0.6,-0.3,0,0.3,0.6,0.9] #25ge
    pub = rospy.Publisher('joint_states', JointState, queue_size=30)
    rospy.init_node('joint_state_publisher')
    rate = rospy.Rate(10) # 10hz
    hello_str = JointState()
    while not rospy.is_shutdown():
	hello_str.header.stamp = rospy.Time.now()           
	for repeat in range(1000):		
		sin_value.insert(0,sin_value.pop())
		#print(sin_value)
		joint[4]=sin_value[0]
		joint[5]=sin_value[1]
		joint[6]=sin_value[2]
		joint[7]=sin_value[3]
		joint[8]=sin_value[4]
		joint[9]=sin_value[5]
		joint[10]=sin_value[6]
		joint[11]=sin_value[7]
		joint[12]=sin_value[8]
		joint[13]=sin_value[9]
		joint[14]=sin_value[10]
		joint[15]=sin_value[11]
		joint[16]=sin_value[12]
		joint[17]=sin_value[13]
		joint[18]=sin_value[14]
		joint[19]=sin_value[15]
		joint[20]=sin_value[16]
		joint[21]=sin_value[17]
		joint[22]=sin_value[18]
		joint[23]=sin_value[19]
		joint[24]=sin_value[20]
		joint[25]=sin_value[21]
		joint[26]=sin_value[22]
		joint[27]=sin_value[23]
		joint[28]=sin_value[24]

		hello_str.header = Header()
		hello_str.header.stamp = rospy.Time.now()
		hello_str.name = [ 'la1', 'la2', 'la-lb' ,'lb1', 'lb2', 'lb-lc' ,'lc1','lc2','lc-ld','ld1','ld2','ld-le','le1','le2','le-lf','lf1','lf2','lf-lg','lg1','lg2','lg-lh','lh1','lh2','lh-li','li1','li2','li-lj','lj1','lj2']
		hello_str.position = [ joint[0], joint[1], joint[2], joint[3], joint[4], joint[5], joint[6],joint[7], joint[8], joint[9], joint[10], joint[11], joint[12], joint[13],joint[14], joint[15], joint[16], joint[17], joint[18], joint[19], joint[20],joint[21], joint[22], joint[23], joint[24], joint[25], joint[26], joint[27],joint[28]]
		hello_str.velocity = []
		hello_str.effort = []
		pub.publish(hello_str)
		rate.sleep() 


	 

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
